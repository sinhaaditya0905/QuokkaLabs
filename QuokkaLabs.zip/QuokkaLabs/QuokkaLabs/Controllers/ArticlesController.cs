﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using QuokkaLabs.Data;
using QuokkaLabs.Models;
using System.Security.Claims;

namespace QuokkaLabs.Controllers
{
    [Route("api/v1/articles")]
    [ApiController]
    [Authorize] // Requires authentication for all methods except GET
    public class ArticlesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ArticlesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [AllowAnonymous] // Open for all
        public IActionResult GetArticles()
        {
            var articles = _context.Articles.ToList();
            return Ok(articles);
        }

        [HttpPost]
        public IActionResult CreateArticle([FromBody] Article article)
        {
            // Validate input
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Retrieve user from the token (assuming it contains the user's ID)
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            article.UserId = userId;

            // Save the article to the database
            _context.Articles.Add(article);
            _context.SaveChanges();

            return Ok("Article created successfully");
        }

        [HttpGet("{id}")]
        [AllowAnonymous] // Open for all
        public IActionResult GetArticle(int id)
        {
            var article = _context.Articles.Find(id);

            if (article == null)
            {
                return NotFound("Article not found");
            }

            return Ok(article);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateArticle(int id, [FromBody] Article updatedArticle)
        {
            // Validate input
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var article = _context.Articles.Find(id);

            if (article == null)
            {
                return NotFound("Article not found");
            }

            // Check if the current user is the owner of the article
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            if (article.UserId != userId)
            {
                return Forbid("You are not authorized to update this article");
            }

            // Update properties
            article.Title = updatedArticle.Title;
            article.Content = updatedArticle.Content;

            _context.SaveChanges();

            return Ok("Article updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteArticle(int id)
        {
            var article = _context.Articles.Find(id);

            if (article == null)
            {
                return NotFound("Article not found");
            }

            // Check if the current user is the owner of the article
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            if (article.UserId != userId)
            {
                return Forbid("You are not authorized to delete this article");
            }

            _context.Articles.Remove(article);
            _context.SaveChanges();

            return Ok("Article deleted successfully");
        }
    }
}
