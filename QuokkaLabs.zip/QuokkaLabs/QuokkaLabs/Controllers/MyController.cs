﻿// MyController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

public interface IController
{
    IActionResult Index();
}

public class MyController : IController
{
    private readonly IConfiguration _configuration;

    public MyController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public IActionResult Index()
    {
        // Your controller logic here
        var valueFromConfig = _configuration["YourConfigKey"];

        return new OkObjectResult($"Hello from MyController! Config value: {valueFromConfig}");
    }
}
