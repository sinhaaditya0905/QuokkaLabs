﻿// SessionController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using QuokkaLabs.Data;

namespace QuokkaLabs.Controllers
{
    [Route("api/v1")]
    [ApiController]
    [Authorize] // Requires authentication for all methods
    public class SessionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SessionController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("article")]
        public IActionResult GetArticle()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var user = _context.Users.Find(userId);

            if (user == null)
            {
                return NotFound("User not found");
            }

            var article = new
            {
                Title = "Welcome to the Session",
                Content = $"Hello, {user.UserName}! This is your article."
            };

            return Ok(article);
        }
    }
}
