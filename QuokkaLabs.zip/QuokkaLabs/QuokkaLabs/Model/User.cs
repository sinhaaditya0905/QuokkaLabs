﻿// User.cs
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using QuokkaLabs.Models;

namespace QuokkaLabs.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string UserName { get; set; }

        [Required]
        public string PasswordHash { get; set; }

        public ICollection<Article> Articles { get; set; }
    }
}
