﻿using Microsoft.AspNetCore.Mvc;

namespace QuokkaLabs.Model
{
    public class UserLoginRequest : Controller
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
